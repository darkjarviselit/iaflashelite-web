# TELEGRAM-E2E-RC7 — Prueba real Telegram texto

Fecha: 2026-05-23

Versión: RC7

## Entorno

- MacBook de prueba.
- Instalación por curl desde `https://iaflashelite-web.vercel.app/gestoria/install.sh`.
- Telegram configurado con `gestoria config telegram`.
- OpenCode Go configurado.

## Resultado

PASS

## Checklist

- Instalación RC7 por curl OK.
- `gestoria doctor` OK.
- `gestoria config telegram` OK.
- BotFather guiado OK.
- Token validado OK.
- `/start` detectado OK.
- ChatId automático OK.
- Mensaje de prueba recibido OK.
- Telegram texto entrante OK.
- Consultas read-only OK.
- Memoria corta OK.
- Intento de acción bloqueado OK.

## Pruebas realizadas

### 1. Consulta de clientes

Usuario: "¿Cuántos clientes tengo?"

Respuesta: GestorIA indicó que hay 3 clientes activos y listó los primeros clientes:

- Demo Clínica Norte.
- Demo García López.
- Demo Martínez Ruiz.

También mantuvo el mensaje seguro: "La IA propone, el gestor aprueba."

### 2. Consulta de urgencia

Usuario: "¿Cuáles tienen más prisa?"

Respuesta: GestorIA ordenó los clientes con más prisa:

- Demo Martínez Ruiz — 3 documentos pendientes — prioridad alta — Modelo 303, 28 may 2026.
- Demo García López — 2 documentos pendientes — prioridad alta — Modelo 130, 29 may 2026.
- Demo Clínica Norte — 2 documentos pendientes — prioridad alta — Modelo 111, 30 may 2026.

También mantuvo el mensaje seguro: "La IA propone, el gestor aprueba."

### 3. Memoria corta de cliente

Usuario: "Háblame de ese cliente."

Respuesta: GestorIA resolvió correctamente "ese cliente" como Demo Martínez Ruiz y devolvió:

- Tipo: SL.
- Prioridad calculada: alta.
- Próximo plazo: Modelo 303, 28 may 2026.
- Notas: Cliente demo para explorar GestorIA.
- Documentos pendientes: DNI administrador, Factura T2, Modelo 303 T2.
- Próximo vencimiento: Vencimiento Modelo 303 — Demo Martínez Ruiz — 28 may, 10:00.
- Revisión pendiente: 1 item(s).

También mantuvo el mensaje seguro: "La IA propone, el gestor aprueba."

### 4. Intento de acción

Usuario: "Ponlo en máxima prioridad."

Respuesta: GestorIA bloqueó la acción y explicó que en esta versión de Telegram solo hace consultas. Las acciones con confirmación quedan para la siguiente fase.

## Confirmaciones de seguridad

- No acciones aplicadas.
- No cambios de negocio.
- No voz.
- No callbacks.
- No LLM.
- No datos inventados.
- Solo chat autorizado.

## Riesgos pendientes

- Voz no implementada.
- Acciones con confirmación no implementadas.
- Botones Confirmar/Cancelar no implementados.
- Multi-admin no implementado.
- Prioridad real persistente pendiente.
- Telegram depende de que GestorIA esté arrancado.
- La detección de cliente explícito puede necesitar mejora si el nombre se dice de forma incompleta.

## Recomendación siguiente

TELEGRAM-CONVERSATION-2 — Acciones con confirmación:

- `pending_actions`.
- Botones Confirmar/Cancelar.
- Crear evento.
- Preparar mensaje.
- Cambiar prioridad solo cuando exista campo real.
