# GestorIA RC3 — Informe de prueba real MacBook

Fecha: 2026-05-23

## Resumen

Resultado general: PASS.

Oscar ha validado una instalación real de GestorIA RC3 en MacBook usando el
instalador web privado del Programa Piloto Privado.

## Versión probada

- Versión: RC3
- Paquete: `gestorai-agent-0.8.0-rc3.tgz`
- Installer URL:
  `https://iaflashelite-web.vercel.app/gestoria/install.sh`
- Tarball URL:
  `https://iaflashelite-web.vercel.app/gestoria/gestorai-agent-0.8.0-rc3.tgz`

## Comando usado

```bash
curl -fsSL https://iaflashelite-web.vercel.app/gestoria/install.sh | GESTORIA_BASE_URL=https://iaflashelite-web.vercel.app/gestoria bash
```

## Resultado de la prueba

| Area | Resultado | Nota |
| --- | --- | --- |
| Instalación por `curl` | PASS | Instalación completada correctamente. |
| `gestoria setup` | PASS | Setup inicial completado correctamente. |
| `gestoria doctor` | PASS | Diagnóstico correcto tras los fixes RC2. |
| `gestoria start` | PASS | Arranque correcto. |
| Apertura en localhost | PASS | La app abre en navegador local. |
| Dashboard | PASS | Visual correcto. |
| Tema oscuro premium | PASS | Apariencia validada. |
| Copiloto flotante | PASS | Aparece abajo a la derecha. |
| Header | PASS | El Copiloto no tapa configuración, sonido ni notificaciones. |
| Clientes | PASS | Vista correcta. |
| Entrada | PASS | Vista correcta. |
| Revisión | PASS | Vista correcta. |
| Calendario | PASS | Vista correcta. |
| Configuración | PASS | Vista correcta. |
| Entrada manual -> Revisión | PASS | Flujo funcional validado. |

## Problemas corregidos desde RC1/RC2

- RC2 corrigió el falso aviso de UI no compilada en instalación global.
- RC2 corrigió el falso error rojo de motor IA inaccesible cuando el usuario
  elige modo local básico.
- RC3 movió el launcher global del Copiloto IA fuera del header.
- RC3 dejó el Copiloto como acción flotante inferior derecha, sin invadir
  configuración, sonido ni notificaciones.

## Bugs pendientes

- `npm` muestra warnings de dependencias deprecated durante la instalación.
  No son bloqueantes para el piloto.
- El dominio `iaflashelite.com` todavía tiene problema TLS; de momento se usa
  la URL de Vercel.
- Falta configurar una API real para probar el Copiloto completo con proveedor IA.
- Falta probar subida y análisis de PDF real.
- Falta probar backup real.
- Falta probar SMTP y Telegram si se quieren incluir en la validación del piloto.

## Recomendación

GestorIA RC3 queda apto para continuar con pruebas guiadas del Programa Piloto
Privado en MacBook.

Siguiente recomendación: ejecutar una prueba funcional con API IA real y un PDF
real de ejemplo, seguida de una prueba de backup y restauración controlada.
