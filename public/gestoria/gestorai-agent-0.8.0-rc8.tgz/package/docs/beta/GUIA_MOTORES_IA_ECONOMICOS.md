# GestorIA — Guía para elegir motor IA sin gastar de más

Opciones económicas, suscripciones útiles y modelos recomendados para usar GestorIA sin complicarte.

## 1. La idea principal

GestorIA necesita un motor IA para responder mejor, resumir información, proponer mensajes y ayudarte a decidir qué revisar primero.

No necesitas empezar pagando APIs caras. GestorIA puede trabajar con suscripciones económicas, sesiones locales o APIs profesionales según tu caso.

La idea no es elegir “el modelo más famoso”. La idea es elegir una opción cómoda, estable y con un coste que no dé miedo usar cada día.

Hay cuatro caminos principales:

- suscripciones económicas para empezar;
- cuentas que quizá ya pagas, como ChatGPT o Codex;
- IA local para máxima privacidad;
- APIs profesionales si ya tienes experiencia o quieres control fino.

## 2. Resumen rápido: qué elegir

| Situación | Mejor opción | Por qué |
| --- | --- | --- |
| Quiero gastar lo mínimo | OpenCode Go | Coste mensual bajo y modelos suficientes para probar GestorIA sin miedo a facturas por uso. |
| Ya pago ChatGPT/Codex | Codex / ChatGPT local | Aprovechas una cuenta que ya tienes, sin pensar como si fuera una API clásica. |
| Quiero coste fijo con modelo potente | MiniMax Token Plan | Interesante si quieres una cuota mensual y buen rendimiento administrativo. |
| Quiero privacidad máxima | Ollama local | Los modelos locales pueden funcionar sin enviar contenido a un proveedor externo. |
| Ya tengo una API profesional | OpenAI / Anthropic / OpenRouter | Buen camino si ya sabes controlar gasto, claves y proveedores. |
| Soy técnico y tengo servidor propio | Proveedor compatible OpenAI | Sirve para LM Studio, LiteLLM, vLLM o servidores internos compatibles. |

## 3. OpenCode Go: recomendado para empezar barato

OpenCode Go es una opción muy razonable para empezar con GestorIA si quieres coste bajo y previsibilidad. Es una suscripción económica: primer mes promocional y después cuota mensual baja, según la documentación oficial de OpenCode Go.

Para una gestoría, esto tiene una ventaja clara: puedes probar el sistema con tranquilidad sin estar mirando cada petición como si fuera una factura abierta.

No debe verse como “una API cara”. Es más parecido a una suscripción de trabajo para usar modelos de IA con un coste contenido.

Requiere una cuenta OpenCode Go y los modelos disponibles pueden cambiar con el tiempo.

| Modelo | Para qué sirve | Recomendación |
| --- | --- | --- |
| MiniMax M2.7 | Documentos, mensajes, tareas tipo secretario, razonamiento administrativo. | Recomendado para GestorIA si está disponible y va fluido en tu cuenta. |
| DeepSeek V4 Flash | Tareas simples, respuestas rápidas y mucho uso. | Buena opción para consultas ligeras y volumen. |
| Qwen3.6 Plus | Uso general equilibrado. | Alternativa si buscas estabilidad y coste razonable. |
| GLM 5 / 5.1 | Uso general y tareas complejas. | Alternativa potente; revisa velocidad y límites. |
| Kimi K2.6 | Casos concretos, razonamiento largo o tareas más técnicas. | No lo usaría como default si se nota lento en tareas administrativas. |

Los modelos y límites pueden cambiar según OpenCode Go.

## 4. Codex / ChatGPT local: si ya pagas ChatGPT

Si ya pagas ChatGPT o usas Codex, esta puede ser una opción muy potente. Codex permite iniciar sesión con una cuenta ChatGPT o usar una API key, según la configuración oficial.

La diferencia importante es esta: si entras con cuenta ChatGPT, no conviene explicarlo como una API clásica. El uso depende de tu cuenta, tu plan y la disponibilidad de modelos en ese momento.

GestorIA no debe leer tokens internos, archivos privados ni configuraciones internas de Codex. Si se usa esta vía, debe hacerse siempre de forma explícita y segura.

Modelos orientativos si aparecen en tu cuenta:

- GPT-5.4-mini: recomendado para uso diario si está disponible; rápido y eficiente.
- GPT-5.4: más calidad para trabajo profesional.
- GPT-5.5: máximo rendimiento para tareas complejas si tienes acceso.
- GPT-5.5 Pro: solo si tienes un plan alto y realmente lo necesitas.

No todos los usuarios tendrán los mismos modelos. Depende de tu cuenta, plan y configuración de Codex.

## 5. MiniMax Token Plan: coste fijo alternativo

MiniMax Token Plan puede ser interesante si quieres un coste mensual más previsible y un modelo fuerte para trabajo de oficina. Su documentación oficial presenta el plan como una suscripción con cuotas por modelo; para M2.7, el uso se mide por peticiones en ventanas móviles de 5 horas.

M2.7 es un candidato fuerte para GestorIA porque encaja bien con tareas como:

- redactar mensajes;
- resumir documentos;
- ayudar a clasificar entradas;
- actuar como secretario administrativo supervisado.

M2.7-highspeed puede interesar si necesitas más velocidad, siempre revisando disponibilidad real y precio antes de recomendarlo a un cliente.

MiniMax M2.7 es una opción a vigilar para GestorIA porque combina coste contenido y buena capacidad para tareas administrativas.

## 6. Ollama local: privacidad máxima

Ollama permite trabajar con modelos locales. Si usas modelos locales, el contenido no tiene por qué salir a un proveedor externo. Esto es atractivo para despachos que priorizan privacidad.

La parte menos cómoda es que requiere más configuración:

- instalar Ollama;
- descargar modelos;
- tener un equipo suficientemente potente;
- aceptar que algunos modelos pueden ir más lentos.

Ollama no requiere API key para uso local, pero no siempre será la opción más cómoda para una gestoría normal.

Ollama es ideal si priorizas privacidad y aceptas más configuración. No siempre será la opción más cómoda para usuarios no técnicos.

## 7. APIs clásicas

Las APIs clásicas siguen siendo una buena opción si ya tienes cuenta, sabes controlar gasto y quieres una configuración profesional.

| Proveedor | Mejor para | Comentario |
| --- | --- | --- |
| OpenAI API | Calidad general y ecosistema profesional. | Buena opción si ya tienes API key y control de gasto. |
| Anthropic API | Redacción, análisis y trabajo con contexto largo. | Interesante para tareas de revisión y documentación. |
| OpenRouter | Comparar varios modelos desde una sola cuenta. | Cómodo si quieres flexibilidad sin abrir muchas cuentas. |
| Groq | Velocidad en modelos compatibles. | Útil para respuestas rápidas si encaja con tu flujo. |
| DeepSeek API | Coste contenido y tareas generales. | Buena alternativa si ya conoces su ecosistema. |
| MiniMax API | M2.7 y otros modelos MiniMax vía API. | Interesante si prefieres API clásica frente a suscripción. |

Estas opciones pueden ser potentes, pero también pueden generar costes por uso.

## 8. Modo avanzado: Proveedor compatible OpenAI

Este modo es para usuarios técnicos o instalaciones acompañadas.

Sirve para conectar GestorIA con sistemas compatibles con el formato de OpenAI Chat Completions, como:

- LM Studio;
- LiteLLM;
- vLLM;
- servidores internos;
- gateways propios.

No debería ser el camino normal para una gestoría que solo quiere empezar. Tampoco debería ser la forma principal de explicar OpenCode Go o Codex a un usuario no técnico.

Si una gestoría necesita este modo, lo razonable es configurarlo con acompañamiento.

## 9. Recomendación final para GestorIA

1. OpenCode Go + MiniMax M2.7 si quieres gastar poco.
2. Codex / ChatGPT local si ya tienes una cuenta potente.
3. MiniMax Token Plan si quieres coste fijo con M2.7.
4. OpenAI / Anthropic / OpenRouter si ya tienes API profesional.
5. Ollama si quieres privacidad y aceptas configuración.
6. Proveedor compatible OpenAI solo para técnicos.

Para empezar el piloto, mi recomendación práctica es:

- empezar con OpenCode Go si el usuario quiere coste bajo;
- usar ChatGPT/Codex si ya lo paga;
- dejar Ollama y proveedor compatible OpenAI para casos con ayuda técnica.

## 10. Avisos importantes

- Los precios cambian.
- Los modelos cambian.
- Las cuentas tienen límites.
- La velocidad puede variar.
- No compartas API keys.
- GestorIA guarda claves de forma cifrada.
- Si usas proveedor externo, el contenido puede salir a ese proveedor.

Datos locales por defecto; el contenido puede salir al proveedor IA configurado.

La IA propone, el gestor aprueba.

## Fuentes consultadas

- OpenCode Go: https://dev.opencode.ai/docs/go/
- OpenAI Codex: https://openai.com/es-419/codex/get-started/
- MiniMax Token Plan: https://platform.minimax.io/docs/token-plan/intro
- Ollama Docs: https://docs.ollama.com/
- Ollama Privacy Policy: https://ollama.com/privacy
