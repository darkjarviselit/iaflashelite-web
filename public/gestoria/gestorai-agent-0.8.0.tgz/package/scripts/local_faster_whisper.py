#!/usr/bin/env python3
"""
GestorIA STT - faster-whisper wrapper.
Uso: python3 local_faster_whisper.py --audio /tmp/audio.m4a --model small --language es
Salida: una linea JSON {"ok": true, "text": "..."} o {"ok": false, "code": "...", "message": "..."}
"""
import sys
import json
import argparse
import os


def emit(payload: dict, exit_code: int = 0) -> None:
    print(json.dumps(payload, ensure_ascii=False), flush=True)
    sys.exit(exit_code)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--audio', required=True)
    parser.add_argument('--model', default='small')
    parser.add_argument('--language', default='es')
    parser.add_argument('--device', default='auto')
    parser.add_argument('--compute-type', default='int8')
    args = parser.parse_args()

    if not os.path.exists(args.audio):
        emit({
            'ok': False,
            'code': 'FILE_NOT_FOUND',
            'message': f'Audio file not found: {args.audio}',
        }, 1)

    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        emit({
            'ok': False,
            'code': 'DEPENDENCY_MISSING',
            'message': f'faster-whisper not installed: {exc}',
        }, 1)

    device = args.device
    if device == 'auto':
        device = 'cpu'

    try:
        model = WhisperModel(args.model, device=device, compute_type=args.compute_type)
        segments, info = model.transcribe(
            args.audio,
            language=args.language,
            vad_filter=True,
            beam_size=1,
            temperature=0,
        )
        text = ' '.join((seg.text or '').strip() for seg in segments).strip()
        emit({
            'ok': True,
            'text': text,
            'language': info.language,
            'duration': info.duration,
        })
    except Exception as exc:
        emit({
            'ok': False,
            'code': 'TRANSCRIPTION_ERROR',
            'message': str(exc),
        }, 1)


if __name__ == '__main__':
    main()
