# GestorIA - Seguridad, privacidad y control humano

GestorIA esta disenada como agente local para gestorias con revision humana. **GestorIA trabaja contigo, no por encima de ti. La IA propone, el gestor aprueba.**

Datos locales por defecto; el contenido puede salir al proveedor IA configurado.

## Datos locales por defecto

GestorIA guarda su configuracion y base de datos en la instalacion local del usuario durante el Programa Piloto Privado.

Rutas principales:

- Configuracion: `~/.gestorai/config.enc`
- Base de datos: `~/.gestorai/data/memory.db`

Esto no significa que todo el contenido permanezca siempre en la maquina: si configuras un proveedor IA externo, los textos usados con ese motor pueden enviarse a ese proveedor. Por eso no debe prometerse que GestorIA sea 100% local cuando se usa IA externa.

## Que esta cifrado

La configuracion principal se guarda en `config.enc`.

Los secretos de configuracion e integraciones se cifran con AES-256-GCM. La clave se deriva localmente a partir de la identidad de maquina/usuario.

Esto aplica a:

- API key del proveedor IA guardada en configuracion.
- Token de Telegram.
- Password SMTP.

## Que NO esta cifrado todavia

`~/.gestorai/data/memory.db` no esta cifrado como base de datos completa.

Puede contener:

- Clientes.
- Checklist documental.
- Entradas inteligentes.
- Mensajes de chat.
- Memoria aprobada.
- Expedientes.
- Eventos de calendario.
- Configuracion no secreta de integraciones.

Protege el equipo y la carpeta local.

## Proveedores IA externos

Puedes usar proveedores como OpenAI, Anthropic, OpenRouter, Groq, DeepSeek, MiniMax, opencode-go o un proveedor compatible OpenAI.

Tambien puedes usar Ollama local u otro servidor local compatible cuando aplique.

Regla practica:

- Si usas proveedor externo, el contenido enviado al motor IA puede salir de tu maquina.
- Si usas proveedor local, revisa igualmente donde corre el servidor y que datos procesa.
- No introduzcas datos sensibles innecesarios durante pruebas.

## Revision humana

GestorIA no debe operar por encima del gestor.

La IA puede:

- Resumir.
- Proponer clasificaciones.
- Sugerir acciones.
- Preparar mensajes.
- Ayudar a interpretar documentos.

El gestor debe:

- Revisar propuestas.
- Aprobar o rechazar cambios.
- Validar informacion fiscal.
- Confirmar comunicaciones.
- Decidir que se envia y a quien.

## Entrada Inteligente

Entrada Inteligente agrupa contenido detectado desde texto manual, email simulado, PDF, carpeta vigilada o chat.

No crea clientes automaticamente. Puede sugerir cliente, origen, resumen o accion, pero requiere revision.

## Telegram

Telegram es un conector del piloto para notificaciones.

Buenas practicas:

- Usa un bot dedicado.
- No compartas el token.
- No pegues el token en capturas.
- Revisa chat ID y permisos.

GestorIA muestra el token enmascarado en la UI/API, no completo.

## SMTP

SMTP permite envio supervisado de emails desde flujos de revision.

No debe describirse como envio automatico.

Buenas practicas:

- Usa app password si tu proveedor la permite.
- Revisa destinatario, asunto y cuerpo antes de enviar.
- Comprueba el remitente configurado.
- Haz prueba SMTP antes de enviar informacion real.

## Backups

El backup CLI crea un archivo `.gestorai-backup.gz`.

Incluye:

- `config.enc`
- `memory.db`
- Archivos WAL/SHM si existen
- Manifest con checksums

El backup esta comprimido y verificado con checksums, pero no esta cifrado entero.

No compartas backups por canales inseguros.

## Restauracion

Restaurar reemplaza datos actuales despues de confirmacion.

Antes de restaurar datos, crea un backup.

Limitacion importante: restaurar en otro equipo puede fallar al descifrar secretos si el cifrado depende de maquina/usuario. En ese caso puede hacer falta reintroducir API keys, token de Telegram o password SMTP.

## Que no compartir

No compartas:

- `~/.gestorai/config.enc`
- `~/.gestorai/data/memory.db`
- Backups `.gestorai-backup.gz`
- API keys
- Tokens de Telegram
- Passwords SMTP
- PDFs reales de clientes
- Capturas con datos fiscales o personales

## Limitaciones actuales

- No hay multiusuario.
- No hay SaaS cloud.
- No hay Gmail real.
- No hay WhatsApp real.
- No hay Google Calendar OAuth.
- No hay presentacion de impuestos.
- No hay cumplimiento legal/fiscal garantizado.
- No hay OCR perfecto en PDFs escaneados.
- No hay RAG avanzado con embeddings.

## Buenas practicas

- Empieza con datos demo.
- Ejecuta `gestoria doctor` antes de una prueba.
- Usa proveedores IA de confianza.
- Usa Ollama/local si quieres reducir salida de datos.
- Crea backups antes de cambios importantes.
- No uses datos reales en demos publicas.
- Revisa cada propuesta antes de aprobar.
- Mantén las claves fuera de chats, tickets y capturas.
