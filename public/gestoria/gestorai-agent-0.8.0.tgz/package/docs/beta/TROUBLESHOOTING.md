# Solucion de Problemas - Programa Piloto GestorIA

Esta guia recoge fallos habituales durante el Programa Piloto Privado de GestorIA y como diagnosticarlos. Datos locales por defecto; el contenido puede salir al proveedor IA configurado. **La IA propone, el gestor aprueba.**

Primer paso recomendado ante cualquier problema:

```bash
gestoria doctor
```

El diagnostico no lo resuelve todo automaticamente, pero ayuda a localizar configuracion, puerto, proveedor IA, base de datos o conectores.

## API key invalida

Sintoma: el Copiloto o la prueba de conexion indica API key invalida.

Causa probable: clave mal copiada, caducada, sin permisos o del proveedor incorrecto.

Solucion: reconfigura el motor IA y prueba conexion.

Comando recomendado:

```bash
gestoria config ai
gestoria doctor
```

## Ollama / LM Studio no arrancado

Sintoma: proveedor local no responde o aparece como inaccesible.

Causa probable: el servidor local no esta ejecutandose o usa otro puerto.

Solucion: arranca Ollama, LM Studio o el servidor compatible y revisa la Base URL.

Comando recomendado:

```bash
gestoria config ai
gestoria doctor
```

## Proveedor OpenAI-compatible no conecta

Sintoma: la prueba de conexion falla con estado no conectado o inaccesible.

Causa probable: Base URL incorrecta, servidor apagado, modelo no disponible o API key necesaria.

Solucion: usa una URL permitida y con endpoint compatible Chat Completions. Ejemplos: `http://localhost:1234/v1` para local o `https://api.example.com/v1` para remoto HTTPS.

Comando recomendado:

```bash
gestoria config ai
```

## Puerto 7777 ocupado

Sintoma: GestorIA no arranca y doctor indica puerto ocupado.

Causa probable: otra instancia o proceso usa el puerto.

Solucion: cambia puerto temporalmente.

Comando recomendado:

```bash
GESTORAI_PORT=7778 npm run dev
```

## No se abre la app

Sintoma: el navegador no abre o muestra error.

Causa probable: servidor no arrancado, puerto distinto o UI no compilada.

Solucion: arranca manualmente y abre URL local.

Comando recomendado:

```bash
npm run build
npm run dev
```

URLs:

- `http://localhost:7777/chat`
- `http://localhost:7777/wizard`

## No hay config

Sintoma: doctor dice que falta configuracion o la app abre wizard.

Causa probable: todavia no se ejecuto setup en ese `GESTORAI_HOME`.

Solucion: ejecuta setup.

Comando recomendado:

```bash
gestoria setup
gestoria doctor
```

## PDF no se lee

Sintoma: upload PDF falla o no crea propuesta.

Causa probable: archivo no es PDF valido, falta cliente/document type o el procesamiento no pudo extraer texto.

Solucion: prueba con un PDF simple con texto seleccionable y vuelve a subirlo.

Comando recomendado:

```bash
gestoria doctor
```

## PDF escaneado sin OCR

Sintoma: el PDF sube, pero el resumen es pobre o no detecta contenido.

Causa probable: el PDF es una imagen escaneada sin texto extraible.

Solucion: usa un PDF con texto seleccionable o aplica OCR externo antes de subirlo.

Comando recomendado:

```bash
gestoria doctor
```

## Telegram no avisa

Sintoma: no llegan notificaciones.

Causa probable: token incorrecto, chat ID incorrecto, bot sin permisos o integracion desactivada.

Solucion: revisa configuracion en UI, prueba conexion y confirma que la integracion esta activa.

Comando recomendado:

```bash
gestoria doctor
```

## SMTP no conecta

Sintoma: prueba SMTP falla o no se envia email.

Causa probable: host/puerto incorrectos, password invalida, app password requerida o TLS mal configurado.

Solucion: revisa credenciales SMTP y prueba conexion desde Configuracion.

Comando recomendado:

```bash
gestoria doctor
```

## Carpeta vigilada no detecta PDFs

Sintoma: se anade un PDF a la carpeta y no aparece en Entrada Inteligente.

Causa probable: integracion desactivada, ruta incorrecta, archivo duplicado, extension no PDF o proceso no arrancado.

Solucion: revisa ruta, activa integracion y prueba escaneo desde Configuracion.

Comando recomendado:

```bash
gestoria doctor
```

## Backup no restaura

Sintoma: restore falla o indica backup corrupto.

Causa probable: archivo incompleto, no es `.gestorai-backup.gz`, checksum invalido o restauracion en otro equipo con secretos no descifrables.

Solucion: verifica el archivo y crea backup previo antes de reintentar.

Comando recomendado:

```bash
gestoria backup
gestoria restore ./gestoria-backup.gestorai-backup.gz
```

## Doctor muestra error

Sintoma: `gestoria doctor` termina con problemas.

Causa probable: depende del punto marcado: config, base de datos, UI, IA, puerto o conectores.

Solucion: corrige primero los errores bloqueantes y deja avisos opcionales para despues.

Comando recomendado:

```bash
gestoria doctor
```

## La UI se ve antigua / dist-ui

Sintoma: cambios visuales no aparecen o la UI parece desactualizada.

Causa probable: UI no recompilada.

Solucion: recompila y reinicia servidor.

Comando recomendado:

```bash
npm run build
npm run dev
```

## Tests fallan

Sintoma: `npm run test` devuelve errores.

Causa probable: entorno incompleto, cambio local o dependencia rota.

Solucion: revisa el primer test fallido y comparte salida con el soporte del piloto.

Comando recomendado:

```bash
npm run typecheck
npm run test
```
