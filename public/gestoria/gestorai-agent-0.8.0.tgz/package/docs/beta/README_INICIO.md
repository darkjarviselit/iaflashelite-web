# GestorIA - Guia de Inicio para Programa Piloto Privado

GestorIA se abre primero a un grupo reducido de gestorias mediante un Programa Piloto Privado con instalacion asistida, configuracion segura y acompanamiento inicial.

Este acceso tambien puede presentarse como Acceso Fundador cuando se comunique a una gestoria invitada.

GestorIA es un agente local para gestorias que ayuda a organizar clientes, documentos, vencimientos, mensajes y propuestas de trabajo. La idea clave es sencilla: **La IA propone, el gestor aprueba.**

## Que es GestorIA

GestorIA combina una aplicacion local, una base de datos local y un motor IA configurable. Sirve para centralizar trabajo operativo de una gestoria: clientes, documentacion pendiente, entradas inteligentes, revision humana, agenda fiscal, memoria y copiloto.

Datos locales por defecto; el contenido puede salir al proveedor IA configurado.

## Para quien es

GestorIA esta pensada para:

- Gestorias pequenas, despachos contables y administrativos que quieren controlar clientes, documentos, vencimientos y mensajes con ayuda de IA supervisada.
- Equipos que quieren probar automatizacion asistida con acompanamiento inicial.
- Equipos que quieran revisar propuestas antes de aplicarlas.
- Casos donde sea importante mantener control humano sobre clientes, documentos y comunicaciones.

No esta orientada aun a despliegues multiusuario, SaaS publico o uso sin onboarding.

## Que incluye el piloto

- Instalacion asistida.
- Configuracion del motor IA.
- Datos demo para primera exploracion.
- Primera prueba guiada.
- Revision de seguridad basica.
- Soporte inicial durante la activacion.

## Que puede hacer hoy

- Mostrar un dashboard operativo con prioridades.
- Gestionar clientes y fichas CRM.
- Mantener checklist documental por cliente.
- Subir PDFs y crear propuestas de revision.
- Agrupar entradas en Entrada Inteligente.
- Permitir aprobar o rechazar propuestas.
- Crear y consultar expedientes inteligentes.
- Gestionar una agenda fiscal local y exportar eventos ICS.
- Usar memoria con aprobacion humana.
- Usar un Copiloto global conectado al motor IA configurado.
- Configurar Telegram, SMTP y carpeta vigilada como conectores del piloto.
- Crear y restaurar backups desde CLI.
- Usar OpenAI, Anthropic, OpenRouter, Ollama local o proveedores compatibles con OpenAI Chat Completions.

## Que no hace todavia

GestorIA no:

- Sustituye al gestor.
- Presenta impuestos.
- Garantiza cumplimiento legal o fiscal.
- Envia emails de forma automatica sin accion del usuario.
- Crea clientes automaticamente desde entradas detectadas.
- Integra Gmail real.
- Integra WhatsApp real.
- Integra Google Calendar OAuth.
- Ofrece multiusuario.
- Funciona como SaaS cloud.
- Garantiza OCR perfecto en PDFs escaneados.
- Incluye RAG avanzado con embeddings.
- Incluye Gemini, Codex local, streaming LLM o custom headers.

## Requisitos

- Node.js 20 o superior.
- npm.
- Acceso al repositorio.
- Un proveedor IA configurado, o Ollama/local compatible si se quiere trabajar en local.
- Opcional: Python, ffmpeg y componentes de voz si se usan funciones de audio.

El Programa Piloto Privado esta orientado primero a instalaciones acompanadas, validacion del flujo real y uso controlado con datos demo antes de introducir datos reales.

## Instalacion desde repo

```bash
git clone <repo>
cd gestorai-agent
npm install
npm run build
```

## Configuracion inicial

Ejecuta:

```bash
npm run setup
```

El asistente pide:

- Nombre de la gestoria.
- Nombre del agente.
- Idioma.
- Motor IA.
- API key si el proveedor la requiere.
- Carpeta local opcional para documentos.
- Carga opcional de datos demo.

La configuracion se guarda en `~/.gestorai/config.enc`.

## Arranque

Para arrancar desde el repo:

```bash
npm run dev
```

URLs habituales:

- `http://localhost:7777/chat` si ya hay configuracion.
- `http://localhost:7777/wizard` si no hay configuracion.

El puerto se puede cambiar con:

```bash
GESTORAI_PORT=7778 npm run dev
```

## Primera prueba recomendada

```bash
npm run doctor
npm run seed:demo
npm run dev
```

Despues abre la app y revisa:

1. Dashboard.
2. Cliente demo.
3. Checklist documental.
4. Upload PDF.
5. Entrada Inteligente.
6. Revision.
7. Copiloto.
8. Agenda fiscal.

## Proveedores IA recomendados

Recomendados:

- OpenAI.
- Anthropic.
- OpenRouter.
- Ollama local.

Avanzados/Piloto:

- Groq.
- DeepSeek.
- MiniMax.
- opencode-go.
- Proveedor compatible OpenAI.

No disponibles todavia:

- Gemini.
- Codex local.
- Streaming.
- Custom headers.

## Datos demo

Para cargar datos demo:

```bash
npm run seed:demo
```

Para limpiarlos:

```bash
npm run clear:demo
```

Usa los datos demo para probar sin mezclar informacion real de clientes.

## Backup basico

El backup real esta disponible por CLI:

```bash
npm run backup
```

Tambien puedes indicar archivo:

```bash
gestoria backup ./mi-backup.gestorai-backup.gz
```

El backup contiene datos de la gestoria. Guardalo en un lugar seguro y no lo compartas.

## Soporte / diagnostico

Ejecuta:

```bash
npm run doctor
```

El diagnostico revisa configuracion, base de datos, UI compilada, proveedor IA, puerto y conectores.

## Siguiente paso

Haz la primera prueba guiada de 20 minutos con `CHECKLIST_PRIMERA_PRUEBA.md`. Si algo falla, consulta `TROUBLESHOOTING.md` antes de usar datos reales.
