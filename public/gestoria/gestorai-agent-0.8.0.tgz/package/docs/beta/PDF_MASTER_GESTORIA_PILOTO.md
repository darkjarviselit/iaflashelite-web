# GestorIA

Guia de Inicio para Programa Piloto Privado

Instalacion asistida, configuracion segura y primera prueba guiada para gestorias.

IAFlashElite · Programa Piloto Privado · 2026

> La IA propone, el gestor aprueba.

> Datos locales por defecto; el contenido puede salir al proveedor IA configurado.

> GestorIA trabaja contigo, no por encima de ti.

## 1. Que es GestorIA

GestorIA es un agente local para gestorias que ayuda a controlar clientes, documentos, vencimientos, entradas, mensajes y memoria operativa.

Su objetivo es reducir trabajo repetitivo y mejorar el control diario del despacho, siempre con revision humana. GestorIA puede proponer acciones, resumir informacion y preparar borradores, pero las decisiones relevantes siguen en manos del gestor.

GestorIA no reemplaza el criterio profesional del despacho. Esta guia esta pensada para una activacion acompanada dentro del Programa Piloto Privado.

## 2. Para quien es el Programa Piloto Privado

El Programa Piloto Privado esta pensado para:

- Gestorias pequenas que quieren ordenar clientes, documentos y vencimientos.
- Despachos contables que necesitan revisar propuestas antes de aplicarlas.
- Administrativos que gestionan documentacion recurrente.
- Usuarios que quieren probar un flujo real antes del lanzamiento publico.

Este programa no esta pensado todavia como autoservicio masivo. Esta pensado como acceso privado con instalacion asistida, configuracion segura y acompanamiento inicial.

Tambien puede presentarse como Acceso Fundador para gestorias invitadas al primer grupo de uso.

## 3. Que incluye el piloto

El piloto incluye:

- Instalacion asistida.
- Configuracion inicial.
- Eleccion de proveedor IA.
- Datos demo para explorar sin informacion real.
- Primera prueba guiada.
- Revision de seguridad basica.
- Diagnostico con `gestoria doctor`.
- Soporte inicial durante el piloto.

La recomendacion es empezar siempre con datos demo, validar el flujo y solo despues introducir informacion real.

## 4. Que puede hacer hoy

| Funcionalidad | Estado | Comentario |
| --- | --- | --- |
| Dashboard operativo | Disponible en piloto | Resume prioridades, revision, agenda y actividad reciente. |
| Clientes/ficha CRM | Disponible en piloto | Permite gestionar fichas, contexto y datos basicos de cliente. |
| Checklist documental | Disponible en piloto | Controla documentos pendientes y estados por cliente. |
| Upload PDF | Piloto con advertencia | Crea propuestas de revision; depende de que el PDF tenga texto util. |
| Entrada Inteligente | Piloto con advertencia | Agrupa entradas y sugiere cliente, resumen y accion. |
| Revision/aprobacion | Disponible en piloto | El gestor aprueba, rechaza o edita propuestas. |
| Expedientes inteligentes | Piloto con advertencia | Permite fuentes, notas, resumen y chat por expediente. |
| Agenda fiscal | Piloto con advertencia | Agenda local con eventos, vencimientos y exportacion ICS. |
| Memoria y Aprendizaje | Piloto con advertencia | La memoria puede requerir aprobacion humana. |
| Copiloto global | Piloto con advertencia | Depende del proveedor IA configurado. |
| Telegram notificaciones | Piloto con advertencia | Conector opcional para avisos. |
| SMTP envio supervisado | Piloto con advertencia | Envio bajo accion del usuario, no automatico. |
| Carpeta vigilada | Piloto con advertencia | Detecta PDFs locales si el conector esta activo. |
| Backup/restore CLI | Disponible en piloto | Backup y restauracion desde comandos CLI. |
| OpenAI-compatible custom provider | Avanzado | Para LM Studio, LiteLLM, vLLM u otros endpoints compatibles. |

## 5. Que no hace todavia

| No disponible todavia | Motivo |
| --- | --- |
| Gmail real | No hay integracion directa de Gmail en esta fase. |
| WhatsApp real | Solo se pueden preparar borradores para uso manual. |
| Google Calendar OAuth | La agenda es local y puede exportar ICS. |
| Multiusuario | El piloto esta orientado a instalacion local individual. |
| SaaS cloud | No se ofrece como plataforma cloud multi-cliente. |
| Presentacion de impuestos | GestorIA ayuda a organizar trabajo, no presenta modelos. |
| Cumplimiento legal/fiscal garantizado | El criterio final debe ser del despacho. |
| OCR perfecto | Los PDFs escaneados pueden requerir OCR externo. |
| RAG avanzado con embeddings | No debe venderse como busqueda semantica avanzada. |
| Gemini | No esta disponible en esta fase. |
| Codex local | No esta disponible en esta fase. |
| Streaming | Las respuestas se tratan como respuesta completa. |
| Custom headers | No se admiten cabeceras personalizadas en esta fase. |

## 6. Instalacion rapida

Instalacion recomendada desde el repositorio:

```bash
git clone <repo>
cd gestorai-agent
npm install
npm run build
npm run setup
npm run doctor
npm run seed:demo
npm run dev
```

URLs habituales:

- `http://localhost:7777/chat` si ya hay configuracion.
- `http://localhost:7777/wizard` si no hay configuracion.

Si el puerto 7777 esta ocupado:

```bash
GESTORAI_PORT=7778 npm run dev
```

## 7. Configuracion del motor IA

GestorIA permite elegir proveedor IA segun el nivel de privacidad, coste y control que quiera la gestoria.

Recomendados:

- OpenAI.
- Anthropic.
- OpenRouter.
- Ollama local.

Avanzados / Piloto:

- Groq.
- DeepSeek.
- MiniMax.
- opencode-go.
- Proveedor compatible OpenAI.

No disponibles todavia:

- Gemini.
- Codex local.
- Streaming.
- Custom headers.

Ollama local puede funcionar sin API key. Un proveedor compatible OpenAI tambien puede funcionar sin API key si el servidor local lo permite. Los proveedores externos habituales requieren API key.

> Si eliges un proveedor externo, los textos enviados al motor IA pueden salir a ese proveedor.

Para cambiar el motor IA:

```bash
gestoria config ai
```

Para diagnosticar la configuracion:

```bash
gestoria doctor
```

## 8. Primera prueba en 20 minutos

| Paso | Accion | Que deberias ver | PASS/FAIL |
| --- | --- | --- | --- |
| 1 | Instalar dependencias y compilar | Proyecto instalado y build correcto | PASS si no hay errores bloqueantes |
| 2 | Ejecutar setup | Asistente inicial completado | PASS si se crea configuracion |
| 3 | Ejecutar doctor | Diagnostico de sistema | PASS si no hay bloqueantes |
| 4 | Cargar datos demo | Clientes y eventos demo | PASS si aparecen datos demo |
| 5 | Abrir Dashboard | Resumen operativo | PASS si carga la vista |
| 6 | Abrir cliente demo | Ficha CRM con checklist | PASS si se ve el cliente |
| 7 | Revisar checklist | Documentos y estados | PASS si se puede revisar |
| 8 | Subir PDF | Propuesta creada | PASS si aparece entrada o revision |
| 9 | Ver Entrada Inteligente | Entrada con origen y resumen | PASS si la entrada aparece |
| 10 | Ir a Revision | Item pendiente | PASS si hay propuesta revisable |
| 11 | Aprobar/rechazar | Estado actualizado | PASS si cambia el estado |
| 12 | Preguntar al Copiloto | Respuesta contextual | PASS si responde sin error IA |
| 13 | Ver Agenda fiscal | Eventos o vencimientos | PASS si se muestran eventos |
| 14 | Crear backup | Archivo `.gestorai-backup.gz` | PASS si se crea y verifica |
| 15 | Limpiar demo si se desea | Datos demo eliminados | PASS si desaparecen datos demo |

## 9. Flujo operativo principal

Entrada -> Analisis -> Propuesta -> Revision -> Aprobacion

Un PDF, email simulado, texto manual o archivo de carpeta vigilada puede entrar en Entrada Inteligente. GestorIA analiza el contenido, estima un cliente probable, prepara un resumen y crea una propuesta.

El gestor revisa esa propuesta antes de aplicar cambios o enviar informacion. Nada sensible debe aplicarse solo.

> La IA propone, el gestor aprueba.

## 10. Comandos esenciales

| Comando | Uso | Riesgo |
| --- | --- | --- |
| `gestoria setup` | Configuracion inicial paso a paso | Sensible |
| `gestoria start` | Arrancar GestorIA | Seguro |
| `gestoria doctor` | Diagnosticar configuracion, IA, puerto y conectores | Seguro |
| `gestoria config ai` | Cambiar proveedor IA, modelo o API key | Sensible |
| `gestoria seed-demo` | Cargar datos demo | Seguro |
| `gestoria clear-demo` | Eliminar datos demo | Destructivo para demo |
| `gestoria backup [archivo]` | Crear backup local | Sensible |
| `gestoria restore <archivo>` | Restaurar y reemplazar datos actuales | Destructivo |
| `gestoria help` | Ver ayuda de comandos | Seguro |

Antes de restaurar datos, crea un backup.

## 11. Seguridad, privacidad y control humano

Rutas principales:

- Configuracion: `~/.gestorai/config.enc`
- Base de datos: `~/.gestorai/data/memory.db`

La configuracion y secretos se cifran con AES-256-GCM. Esto incluye API key, token de Telegram y password SMTP.

`memory.db` no esta cifrado todavia como base de datos completa. Puede contener clientes, mensajes, entradas, memoria aprobada, expedientes y eventos.

El backup `.gestorai-backup.gz` esta comprimido y verificado con checksums, pero no esta cifrado entero. No debe compartirse por canales inseguros.

Restaurar en otro equipo puede fallar al descifrar secretos porque el cifrado depende de maquina/usuario. Puede hacer falta reintroducir API keys, token de Telegram o password SMTP.

Si configuras un proveedor IA externo, el contenido enviado al motor IA puede salir a ese proveedor.

En flujos criticos, la revision humana no es decorativa: es parte del funcionamiento esperado del piloto.

> GestorIA trabaja contigo, no por encima de ti.

## 12. Proveedores IA compatibles

| Proveedor | Estado | API key | Uso recomendado |
| --- | --- | --- | --- |
| OpenAI | Recomendado | Si | Uso general con buena compatibilidad. |
| Anthropic | Recomendado | Si | Redaccion, analisis y tareas con contexto. |
| OpenRouter | Recomendado | Si | Acceso flexible a varios modelos. |
| Ollama local | Recomendado local | No normalmente | Uso local si el modelo esta instalado. |
| Groq | Avanzado / Piloto | Si | Respuestas rapidas con modelos compatibles. |
| DeepSeek | Avanzado / Piloto | Si | Alternativa externa compatible. |
| MiniMax | Avanzado / Piloto | Si | Proveedor avanzado disponible en config. |
| opencode-go | Avanzado / Piloto | Si | Uso tecnico avanzado. |
| OpenAI-compatible | Avanzado | Depende | LM Studio, LiteLLM, vLLM u otros endpoints compatibles. |

## 13. Solucion de problemas frecuentes

| Problema | Causa probable | Solucion |
| --- | --- | --- |
| API key invalida | Clave incorrecta, caducada o sin permisos | Ejecutar `gestoria config ai` y despues `gestoria doctor`. |
| Puerto 7777 ocupado | Otro proceso usa el puerto | Usar `GESTORAI_PORT=7778 npm run dev`. |
| Proveedor custom no conecta | Base URL, modelo o servidor incorrecto | Revisar URL y probar conexion desde config IA. |
| Ollama/LM Studio apagado | Servidor local no iniciado | Arrancar el servidor local y repetir prueba. |
| PDF no se lee | Archivo no valido o sin texto util | Probar con PDF simple con texto seleccionable. |
| PDF escaneado sin OCR | El PDF es imagen escaneada | Aplicar OCR externo antes de subirlo. |
| Telegram no avisa | Token, chat ID o permisos incorrectos | Revisar conector y ejecutar `gestoria doctor`. |
| SMTP no conecta | Host, puerto, TLS o password incorrectos | Revisar SMTP y probar conexion. |
| Backup/restore falla | Archivo corrupto, ruta incorrecta o secretos no descifrables | Crear backup previo y verificar archivo. |
| UI antigua / dist-ui | UI no recompilada | Ejecutar `npm run build` y reiniciar. |

## 14. Guion demo resumido

Duracion objetivo: 2-3 minutos.

1. Dashboard: mostrar prioridades y actividad.
2. Cliente demo: abrir ficha y checklist.
3. PDF: subir documento y crear propuesta.
4. Entrada Inteligente: revisar origen, cliente probable y resumen.
5. Revision: aprobar o rechazar.
6. Agenda: mostrar vencimientos y eventos.
7. Memoria: explicar aprendizaje con aprobacion.
8. Copiloto: hacer una pregunta simple.
9. Backup/doctor: mostrar comandos de confianza.
10. Cierre: explicar el piloto con acompanamiento.

Frase de cierre:

> GestorIA ayuda a controlar clientes, documentos, vencimientos y mensajes con IA supervisada. La IA propone, el gestor aprueba.

## 15. Anexos tecnicos

### Anexo A - Scripts npm utiles

| Script | Uso |
| --- | --- |
| `npm run setup` | Ejecutar setup desde el repo. |
| `npm run doctor` | Diagnostico desde el repo. |
| `npm run dev` | Arrancar en modo desarrollo. |
| `npm run build` | Compilar servidor y UI. |
| `npm run test` | Ejecutar tests. |
| `npm run typecheck` | Comprobar tipos. |
| `npm run seed:demo` | Cargar datos demo. |
| `npm run clear:demo` | Limpiar datos demo. |
| `npm run backup` | Crear backup. |
| `npm run restore` | Restaurar backup con ruta de archivo. |

### Anexo B - Comandos que no existen todavia

No forman parte de esta guia ni deben presentarse como disponibles:

- `login`
- `logout`
- `serve`
- `migrate`
- `export`
- `import`
- `config smtp`
- `config telegram`
- `gmail`
- `whatsapp`
- `calendar sync`
- `oauth`
- `rag`

### Anexo C - Limites actuales

- No hay Gmail real.
- No hay WhatsApp real.
- No hay Google Calendar OAuth.
- No hay multiusuario.
- No hay SaaS cloud.
- No hay OCR perfecto.
- No hay RAG avanzado con embeddings.
- No hay Codex local.
- No hay Gemini.
- No hay streaming.
- No hay custom headers.
