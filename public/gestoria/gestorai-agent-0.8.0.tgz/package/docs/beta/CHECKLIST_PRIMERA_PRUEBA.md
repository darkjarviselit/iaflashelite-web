# Checklist de Primera Prueba - Programa Piloto Privado

Objetivo: comprobar en unos 20 minutos si GestorIA encaja con el flujo de documentos, clientes y vencimientos de una gestoria.

Esta primera prueba forma parte del Programa Piloto Privado y debe hacerse con datos demo o informacion no sensible. **La IA propone, el gestor aprueba.**

Datos locales por defecto; el contenido puede salir al proveedor IA configurado.

## 1. Clonar repo

Accion:

```bash
git clone <repo>
cd gestorai-agent
```

Que deberia verse: carpeta `gestorai-agent` con el proyecto.

PASS/FAIL: PASS si puedes entrar en la carpeta. FAIL si Git no encuentra el repo o no tienes permisos.

Si falla: revisa acceso al repositorio y vuelve a clonar.

## 2. Instalar dependencias

Accion:

```bash
npm install
```

Que deberia verse: instalacion completada sin errores bloqueantes.

PASS/FAIL: PASS si termina correctamente. FAIL si npm corta con error.

Si falla: comprueba Node.js 20 o superior y conectividad.

## 3. Compilar

Accion:

```bash
npm run build
```

Que deberia verse: compilacion TypeScript y Vite completada.

PASS/FAIL: PASS si termina en OK. FAIL si hay errores de tipos o build.

Si falla: comparte el error completo con el soporte del piloto.

## 4. Ejecutar setup

Accion:

```bash
npm run setup
```

Que deberia verse: asistente de configuracion en terminal.

PASS/FAIL: PASS si se crea configuracion. FAIL si se cancela o falta algun dato obligatorio.

Si falla: vuelve a lanzar `npm run setup`.

## 5. Configurar motor IA

Accion: selecciona proveedor y modelo durante setup o despues con:

```bash
gestoria config ai
```

Que deberia verse: proveedor configurado y prueba de conexion si aplica.

PASS/FAIL: PASS si el proveedor conecta o se guarda con advertencia local controlada. FAIL si la API key es invalida o el proveedor no responde.

Si falla: revisa API key, modelo, Ollama/LM Studio arrancado o Base URL.

## 6. Ejecutar doctor

Accion:

```bash
npm run doctor
```

Que deberia verse: diagnostico de configuracion, base de datos, UI, IA, puerto y conectores.

PASS/FAIL: PASS si no hay bloqueantes. WARN aceptable si SMTP, Telegram o voz no estan configurados.

Si falla: corrige el punto indicado por doctor.

## 7. Cargar datos demo

Accion:

```bash
npm run seed:demo
```

Que deberia verse: mensaje de datos demo cargados.

PASS/FAIL: PASS si aparecen clientes demo. FAIL si la base de datos no esta disponible.

Si falla: ejecuta `npm run doctor`.

## 8. Arrancar app

Accion:

```bash
npm run dev
```

Que deberia verse: servidor local en puerto 7777.

PASS/FAIL: PASS si la app abre o queda disponible. FAIL si el puerto esta ocupado.

Si falla:

```bash
GESTORAI_PORT=7778 npm run dev
```

## 9. Abrir Dashboard

Accion: abre `http://localhost:7777/chat` y entra en Dashboard.

Que deberia verse: resumen operativo con clientes, revision, agenda y actividad.

PASS/FAIL: PASS si el dashboard carga. FAIL si la pantalla queda vacia o da error.

Si falla: ejecuta `npm run build` y reinicia `npm run dev`.

## 10. Abrir cliente demo

Accion: entra en Clientes y abre un cliente demo.

Que deberia verse: ficha CRM con datos, checklist, propuestas y contexto.

PASS/FAIL: PASS si se ve la ficha. FAIL si no hay clientes demo.

Si falla: ejecuta `npm run seed:demo`.

## 11. Revisar checklist documental

Accion: en la ficha del cliente, revisa documentos pendientes.

Que deberia verse: lista de documentos con estados.

PASS/FAIL: PASS si puedes ver o actualizar estados. FAIL si no aparece checklist.

Si falla: revisa que el cliente demo existe.

## 12. Subir PDF

Accion: sube un PDF desde la ficha de cliente.

Que deberia verse: mensaje de propuesta creada para revision.

PASS/FAIL: PASS si se crea entrada/propuesta. FAIL si el archivo no es PDF o no se procesa.

Si falla: prueba con un PDF simple con texto seleccionable.

## 13. Ver Entrada Inteligente

Accion: abre Entrada Inteligente.

Que deberia verse: entrada procedente de PDF, texto manual, email simulado o carpeta vigilada.

PASS/FAIL: PASS si aparece la entrada. FAIL si no aparece tras subir PDF.

Si falla: revisa filtros y estado de la entrada.

## 14. Ir a Revision

Accion: abre Revision.

Que deberia verse: propuesta pendiente relacionada con documento, checklist o mensaje.

PASS/FAIL: PASS si hay propuesta. FAIL si no hay items pendientes.

Si falla: vuelve a subir PDF o crea entrada manual.

## 15. Aprobar o rechazar propuesta

Accion: abre la propuesta y aprueba o rechaza.

Que deberia verse: cambio de estado y registro de la decision.

PASS/FAIL: PASS si el estado cambia. FAIL si el boton no responde.

Si falla: recarga la app y revisa `npm run doctor`.

## 16. Preguntar al Copiloto

Accion: abre el Copiloto y pregunta algo sobre clientes demo o agenda.

Que deberia verse: respuesta del asistente con contexto disponible.

PASS/FAIL: PASS si responde. FAIL si aparece error de IA.

Si falla:

```bash
gestoria config ai
```

## 17. Ver Agenda fiscal

Accion: abre Calendario.

Que deberia verse: vencimientos demo y eventos locales.

PASS/FAIL: PASS si se ven eventos. FAIL si no hay eventos tras seed demo.

Si falla: vuelve a ejecutar `npm run seed:demo`.

## 18. Crear backup

Accion:

```bash
npm run backup
```

Que deberia verse: archivo `.gestorai-backup.gz` creado y verificado.

PASS/FAIL: PASS si se crea el backup. FAIL si no hay config o base de datos.

Si falla: ejecuta `npm run doctor`.

## 19. Limpiar demo si se desea

Accion:

```bash
npm run clear:demo
```

Que deberia verse: datos demo eliminados.

PASS/FAIL: PASS si los clientes demo desaparecen. FAIL si la base de datos no responde.

Si falla: no borres datos manualmente; pide soporte del piloto.
