# Comandos de GestorIA - Instalacion, diagnostico y seguridad

Esta guia documenta solo comandos reales utiles durante la instalacion asistida, el diagnostico y el uso seguro de GestorIA. No incluye comandos planeados o inexistentes.

Datos locales por defecto; el contenido puede salir al proveedor IA configurado. **La IA propone, el gestor aprueba.**

## CLI

## gestoria setup

Que hace: lanza el asistente inicial y guarda configuracion en `~/.gestorai/config.enc`.

Cuando usarlo: primera instalacion o reconfiguracion asistida.

Ejemplo:

```bash
gestoria setup
```

Riesgo: sensible. Puede cambiar configuracion.

## gestoria start

Que hace: arranca la app local.

Cuando usarlo: uso normal tras compilar/instalar.

Ejemplo:

```bash
gestoria start
```

Riesgo: seguro.

## gestoria doctor

Que hace: revisa configuracion, base de datos, UI, proveedor IA, puerto y conectores.

Cuando usarlo: tras setup, antes de una demo o como primer comando ante problemas.

Ejemplo:

```bash
gestoria doctor
```

Riesgo: seguro.

## gestoria config ai

Que hace: cambia proveedor IA, modelo, API key y opciones relacionadas.

Cuando usarlo: API key invalida, cambio de proveedor o prueba de OpenAI-compatible.

Ejemplo:

```bash
gestoria config ai
```

Riesgo: sensible. Cambia credenciales y proveedor IA.

## gestoria seed-demo

Que hace: carga clientes, checklist, expedientes y eventos demo.

Cuando usarlo: primera prueba, demo comercial o entorno de entrenamiento.

Ejemplo:

```bash
gestoria seed-demo
```

Riesgo: seguro en entorno demo. Evita mezclarlo con datos reales si no quieres datos de ejemplo.

## gestoria clear-demo

Que hace: elimina los datos demo conocidos.

Cuando usarlo: despues de una prueba o demo.

Ejemplo:

```bash
gestoria clear-demo
```

Riesgo: destructivo para datos demo. No borra toda la instalacion, pero elimina clientes demo, checklist demo, expedientes demo y eventos demo.

## gestoria backup [archivo]

Que hace: crea un backup `.gestorai-backup.gz` con configuracion y base de datos.

Cuando usarlo: antes de restaurar, antes de pruebas sensibles o periodicamente.

Ejemplos:

```bash
gestoria backup
gestoria backup ./gestoria-backup.gestorai-backup.gz
```

Riesgo: sensible. El backup contiene datos de la gestoria y debe guardarse en un lugar seguro.

## gestoria restore <archivo>

Que hace: restaura un backup y reemplaza datos actuales tras confirmacion.

Cuando usarlo: recuperar una instalacion o mover datos con soporte.

Ejemplo:

```bash
gestoria restore ./gestoria-backup.gestorai-backup.gz
```

Riesgo: destructivo. Antes de restaurar datos, crea un backup.

## gestoria help

Que hace: muestra ayuda de comandos.

Cuando usarlo: comprobar sintaxis disponible.

Ejemplo:

```bash
gestoria help
```

Riesgo: seguro.

## Scripts npm

## npm run setup

Equivalente de desarrollo para ejecutar setup desde el repo.

```bash
npm run setup
```

Riesgo: sensible.

## npm run doctor

Ejecuta diagnostico desde el repo.

```bash
npm run doctor
```

Riesgo: seguro.

## npm run dev

Arranca GestorIA en modo desarrollo desde el repo.

```bash
npm run dev
```

Riesgo: seguro.

## npm run build

Compila servidor y UI.

```bash
npm run build
```

Riesgo: seguro.

## npm run test

Ejecuta tests.

```bash
npm run test
```

Riesgo: seguro.

## npm run typecheck

Ejecuta comprobacion de tipos.

```bash
npm run typecheck
```

Riesgo: seguro.

## npm run seed:demo

Carga datos demo.

```bash
npm run seed:demo
```

Riesgo: seguro en entorno demo.

## npm run clear:demo

Elimina datos demo.

```bash
npm run clear:demo
```

Riesgo: destructivo para datos demo.

## npm run backup

Crea backup desde el repo.

```bash
npm run backup
```

Riesgo: sensible.

## npm run restore

Restaura backup desde el repo. Necesita ruta de archivo.

```bash
npm run restore -- ./gestoria-backup.gestorai-backup.gz
```

Riesgo: destructivo. Antes de restaurar datos, crea un backup.

## Comandos que no existen en esta version del piloto

No documentar ni usar como si estuvieran disponibles:

- `login`
- `logout`
- `serve`
- `migrate`
- `export`
- `import`
- `config smtp`
- `config telegram`
- `gmail`
- `whatsapp`
- `calendar sync`
- `oauth`
- `rag`
