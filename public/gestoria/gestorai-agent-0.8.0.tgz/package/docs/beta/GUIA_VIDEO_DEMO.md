# Guion Demo - GestorIA Programa Piloto Privado

Duracion objetivo: 2-3 minutos.

Objetivo: mostrar valor rapido y confianza, no explicar toda la tecnologia. La demo debe transmitir control, revision humana y utilidad operativa para gestorias.

Datos locales por defecto; el contenido puede salir al proveedor IA configurado.

## 1. Apertura: que es GestorIA

Pantalla: app abierta en Dashboard.

Frase sugerida:

> GestorIA ayuda a una gestoria a controlar clientes, documentos, vencimientos y mensajes desde una app local con revision humana.

Refuerzo:

> La IA propone, el gestor aprueba.

Evita explicar arquitectura interna en esta escena.

## 2. Dashboard: prioridades

Pantalla: Dashboard.

Mostrar:

- Clientes activos.
- Revision pendiente.
- Agenda o vencimientos.
- Actividad reciente.

Frase sugerida:

> Lo primero es ver que requiere atencion: documentos, propuestas, vencimientos y actividad reciente.

## 3. Cliente demo: checklist

Pantalla: ficha de cliente demo.

Mostrar:

- Datos del cliente.
- Checklist documental.
- Propuestas o contexto.

Frase sugerida:

> Cada cliente tiene una ficha con su checklist documental y contexto operativo.

## 4. Subir PDF

Pantalla: upload PDF en cliente.

Mostrar:

- Subida de PDF demo.
- Mensaje de propuesta creada.

Frase sugerida:

> Al subir un PDF, GestorIA no aplica cambios a ciegas: crea una propuesta para revisar.

## 5. Entrada Inteligente

Pantalla: Entrada Inteligente.

Mostrar:

- Origen.
- Cliente probable.
- Confianza.
- Accion sugerida.

Frase sugerida:

> Entrada Inteligente agrupa lo detectado y ayuda a decidir que revisar primero.

## 6. Revision: aprobar/rechazar

Pantalla: Revision.

Mostrar:

- Item pendiente.
- Botones aprobar/rechazar.
- Edicion si aplica.

Frase sugerida:

> La IA propone, el gestor aprueba. Nada importante deberia entrar sin revision humana.

## 7. Agenda fiscal

Pantalla: Calendario.

Mostrar:

- Vencimientos demo.
- Eventos por cliente.
- Export ICS si encaja.

Frase sugerida:

> La agenda ayuda a visualizar vencimientos y trabajo pendiente, sin sustituir la validacion fiscal del gestor.

## 8. Memoria y Aprendizaje

Pantalla: Memoria.

Mostrar:

- Propuestas pendientes.
- Memoria aprobada.

Frase sugerida:

> La memoria tambien sigue el mismo principio: se propone aprendizaje, pero se aprueba antes de guardarlo como conocimiento util.

## 9. Copiloto

Pantalla: Copiloto global.

Mostrar:

- Pregunta simple sobre cliente demo o agenda.
- Respuesta contextual.

Frase sugerida:

> El Copiloto permite consultar contexto de trabajo y acelerar tareas repetitivas.

## 10. Backup/doctor

Pantalla: terminal o Configuracion.

Mostrar comandos:

```bash
gestoria doctor
gestoria backup
```

Frase sugerida:

> Doctor ayuda a revisar el estado de la instalacion y backup permite guardar una copia de seguridad.

## 11. Cierre comercial

Pantalla: Dashboard o cliente.

Frase sugerida:

> Este piloto privado esta pensado para validar el flujo real con acompanamiento: clientes, documentos, revision, agenda y copiloto en una instalacion local.

Otra frase util:

> Puedes usar OpenAI, Anthropic, OpenRouter, Ollama local o un proveedor compatible OpenAI.

## Frases recomendadas

- "GestorIA ayuda a controlar clientes, documentos, vencimientos y mensajes."
- "La IA propone, el gestor aprueba."
- "Datos locales por defecto; el contenido puede salir al proveedor IA configurado."
- "Este piloto privado esta pensado para validar el flujo real con acompanamiento."
- "Puedes usar OpenAI, Anthropic, OpenRouter, Ollama local o un proveedor compatible OpenAI."

## Que NO decir

- "Sustituye al gestor."
- "Presenta impuestos automaticamente."
- "Funciona con Gmail o WhatsApp real."
- "Es completamente local con cualquier proveedor."
- "Cumple legalmente todo por ti."
- "Es un SaaS multiusuario."

## Tono

- Directo.
- Profesional.
- Sin prometer automatizacion total.
- Sin hablar de features futuras como si ya existieran.
- Reforzando siempre control humano.
