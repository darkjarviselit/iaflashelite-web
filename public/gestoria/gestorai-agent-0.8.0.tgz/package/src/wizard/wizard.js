/**
 * Wizard de configuración inicial — JS plano sin framework.
 * 4 pasos: gestoría → LLM/key → agente/documentos → confirmación.
 */
(function () {
    const state = {
        step: 0,
        gestoriaName: "",
        llmProvider: "opencode-go",
        llmModel: "minimax-m2.7",
        llmApiKey: "",
        ollamaBaseUrl: "http://localhost:11434",
        agentName: "GestorIA",
        documentTypes: "DNI/NIF, Factura, Justificante bancario, Modelo fiscal, Contrato",
    };

    const PROVIDERS = [
        {
            id: "opencode-go", label: "OpenCode Go", section: "subscription",
            models: ["minimax-m2.7", "minimax-m2.5", "deepseek-v4-flash", "deepseek-v4-pro", "kimi-k2.6", "qwen3.6-plus", "glm-5.1"],
            needsKey: true,
            help: "Suscripción mensual. Consigue tu key en opencode.ai/go.",
        },
        {
            id: "openrouter", label: "OpenRouter", section: "subscription",
            models: ["openai/gpt-4o-mini", "anthropic/claude-3.5-sonnet", "meta-llama/llama-3.3-70b-instruct"],
            needsKey: true,
            help: "Suscripción/pago por uso. Consigue tu key en openrouter.ai/keys.",
        },
        {
            id: "minimax", label: "MiniMax", section: "api",
            models: ["MiniMax-M1", "abab6.5-chat"], needsKey: true,
            help: "Pago por uso. Consigue tu key en api.minimax.chat → consola.",
        },
        {
            id: "deepseek", label: "DeepSeek", section: "api",
            models: ["deepseek-chat", "deepseek-reasoner"], needsKey: true,
            help: "Pago por uso. Consigue tu key en platform.deepseek.com/api_keys.",
        },
        {
            id: "anthropic", label: "Anthropic (Claude)", section: "api",
            models: ["claude-sonnet-4-6", "claude-opus-4-6", "claude-haiku-4-5"], needsKey: true,
            help: "Pago por uso. Consigue tu key en console.anthropic.com → API Keys.",
        },
        {
            id: "openai", label: "OpenAI (GPT)", section: "api",
            models: ["gpt-4o-mini", "gpt-4o", "gpt-4-turbo"], needsKey: true,
            help: "Pago por uso. Consigue tu key en platform.openai.com/api-keys.",
        },
        {
            id: "groq", label: "Groq (Llama rápido)", section: "api",
            models: ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768"],
            needsKey: true,
            help: "Pago por uso. Consigue tu key en console.groq.com/keys.",
        },
        {
            id: "ollama", label: "Ollama (local, gratis)", section: "local",
            models: ["llama3.2", "llama3.1", "mistral", "phi3"], needsKey: false,
            help: "100% gratis. Requiere tener Ollama instalado (ollama.com/download).",
        },
    ];

    const SECTION_META = {
        subscription: { title: "Suscripción mensual", desc: "Una cuota fija al mes." },
        api: { title: "Pago por uso (API key)", desc: "Pagas solo lo que consumes." },
        local: { title: "Local gratis", desc: "Corre en tu equipo. Cero coste, sin internet." },
    };

    function currentProvider() {
        return PROVIDERS.find(function (p) { return p.id === state.llmProvider; });
    }

    function splitCsv(value) {
        return value.split(",").map(function (item) { return item.trim(); }).filter(Boolean);
    }

    const root = document.getElementById("container");

    function render() {
        switch (state.step) {
            case 0: return renderStep0();
            case 1: return renderStep1();
            case 2: return renderStep2();
            case 3: return renderStep3();
        }
    }

    function showError(msg) {
        const e = document.getElementById("error");
        if (e) e.textContent = msg || "";
    }

    function renderStep0() {
        root.innerHTML = `
            <div class="step-tag">Paso 1 de 4</div>
            <h1>Configurar GestorIA</h1>
            <p class="muted">Agente local para gestorías y despachos contables.</p>
            <label>Nombre de la gestoría</label>
            <input id="gestoriaName" placeholder="Ej: Asesoría López" value="${state.gestoriaName}" />
            <div class="error" id="error"></div>
            <div class="row">
                <span></span>
                <button class="btn btn-primary" id="next">Siguiente →</button>
            </div>
        `;
        document.getElementById("next").onclick = function () {
            const name = document.getElementById("gestoriaName").value.trim();
            if (!name) return showError("Escribe el nombre de la gestoría.");
            state.gestoriaName = name;
            state.step = 1; render();
        };
    }

    function renderStep1() {
        function pillsForSection(section) {
            return PROVIDERS
                .filter(function (p) { return p.section === section; })
                .map(function (p) {
                    const cls = p.id === state.llmProvider ? "provider-pill active" : "provider-pill";
                    return `<div class="${cls}" data-id="${p.id}">${p.label}</div>`;
                }).join("");
        }
        function sectionBlock(key) {
            const meta = SECTION_META[key];
            return `
                <div class="section-title">${meta.title}</div>
                <div class="section-desc">${meta.desc}</div>
                <div class="providers">${pillsForSection(key)}</div>
            `;
        }
        const current = currentProvider();
        const modelOptions = current.models.map(function (m) {
            const sel = m === state.llmModel ? " selected" : "";
            return `<option value="${m}"${sel}>${m}</option>`;
        }).join("");
        const ollamaInput = !current.needsKey ? `
            <label>URL de Ollama</label>
            <input id="ollamaBaseUrl" value="${state.ollamaBaseUrl}" />
            <div class="hint">Ollama suele escuchar en http://localhost:11434.</div>
        ` : "";
        const keyInput = current.needsKey ? `
            <label>API key</label>
            <input id="llmApiKey" type="password" placeholder="sk-..." value="${state.llmApiKey}" />
            <div class="hint">${current.help} La key se cifra antes de guardarse en disco.</div>
        ` : `<div class="hint">${current.help}</div>`;

        root.innerHTML = `
            <div class="step-tag">Paso 2 de 4</div>
            <h1>Elige tu motor de IA</h1>
            <p class="muted">Puedes cambiarlo más tarde desde configuración.</p>
            ${sectionBlock("subscription")}
            ${sectionBlock("api")}
            ${sectionBlock("local")}
            <label>Modelo</label>
            <select id="llmModel">${modelOptions}</select>
            ${keyInput}${ollamaInput}
            <div class="error" id="error"></div>
            <div class="row">
                <button class="btn btn-ghost" id="back">← Atrás</button>
                <button class="btn btn-primary" id="next">Siguiente →</button>
            </div>
        `;
        document.querySelectorAll(".provider-pill").forEach(function (el) {
            el.onclick = function () {
                state.llmProvider = el.getAttribute("data-id");
                state.llmModel = currentProvider().models[0];
                render();
            };
        });
        document.getElementById("back").onclick = function () { state.step = 0; render(); };
        document.getElementById("next").onclick = function () {
            const provider = currentProvider();
            state.llmModel = document.getElementById("llmModel").value || provider.models[0];
            if (provider.needsKey) {
                const key = document.getElementById("llmApiKey").value.trim();
                if (!key) return showError("Falta la API key.");
                state.llmApiKey = key;
            } else {
                state.ollamaBaseUrl = document.getElementById("ollamaBaseUrl").value.trim() || state.ollamaBaseUrl;
                state.llmApiKey = "";
            }
            state.step = 2; render();
        };
    }

    function renderStep2() {
        root.innerHTML = `
            <div class="step-tag">Paso 3 de 4</div>
            <h1>Agente y documentos</h1>
            <p class="muted">Define cómo se presentará el agente y qué documentos suelen pedir tus expedientes.</p>
            <label>Nombre del agente</label>
            <input id="agentName" value="${state.agentName}" />
            <label>Tipos de documentos habituales</label>
            <input id="documentTypes" value="${state.documentTypes}" />
            <div class="hint">Separados por coma.</div>
            <div class="error" id="error"></div>
            <div class="row">
                <button class="btn btn-ghost" id="back">← Atrás</button>
                <button class="btn btn-primary" id="next">Siguiente →</button>
            </div>
        `;
        document.getElementById("back").onclick = function () { state.step = 1; render(); };
        document.getElementById("next").onclick = function () {
            const name = document.getElementById("agentName").value.trim();
            const docs = document.getElementById("documentTypes").value.trim();
            state.agentName = name || "GestorIA";
            state.documentTypes = docs || state.documentTypes;
            state.step = 3; render();
        };
    }

    function renderStep3() {
        root.innerHTML = `
            <div class="step-tag">Paso 4 de 4</div>
            <h1>Listo para arrancar</h1>
            <p class="muted">Revisa la configuración. Si todo cuadra, pulsa "Guardar y empezar".</p>
            <div style="margin-top:12px; line-height:1.9;">
                <div>Gestoría: <b>${state.gestoriaName}</b></div>
                <div>Agente: <b>${state.agentName}</b></div>
                <div>Motor: <b>${state.llmProvider}</b> · ${state.llmModel}</div>
                <div>Documentos: <b>${splitCsv(state.documentTypes).join(", ")}</b></div>
            </div>
            <div class="error" id="error"></div>
            <div id="success" style="display:none;"></div>
            <div class="row">
                <button class="btn btn-ghost" id="back">← Atrás</button>
                <button class="btn btn-primary" id="save">Guardar y empezar</button>
            </div>
        `;
        document.getElementById("back").onclick = function () { state.step = 2; render(); };
        document.getElementById("save").onclick = async function () {
            showError("");
            try {
                const res = await fetch("/api/config", {
                    method: "POST",
                    headers: { "content-type": "application/json" },
                    body: JSON.stringify({
                        gestoriaName: state.gestoriaName,
                        agentName: state.agentName,
                        llmProvider: state.llmProvider,
                        llmModel: state.llmModel,
                        llmApiKey: state.llmApiKey,
                        ollamaBaseUrl: state.ollamaBaseUrl,
                        documentTypes: splitCsv(state.documentTypes),
                    }),
                });
                if (!res.ok) {
                    const err = await res.json().catch(function () { return { error: "Error desconocido." }; });
                    return showError(err.error || "Error al guardar.");
                }
                const s = document.getElementById("success");
                s.className = "success";
                s.style.display = "block";
                s.textContent = "Configuración guardada. Redirigiendo al chat...";
                setTimeout(function () { window.location.href = "/chat"; }, 800);
            } catch (e) {
                showError("No se pudo contactar con el servidor.");
            }
        };
    }

    render();
})();
