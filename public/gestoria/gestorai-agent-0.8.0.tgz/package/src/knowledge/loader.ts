import { existsSync, readFileSync, readdirSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export interface SkillMarkdown {
    id: string;
    layer: number;
    domain: string;
    triggers: string[];
    priority: string;
    content: string;
    alwaysActive?: boolean;
    mode?: string;
}

const __dirname = dirname(fileURLToPath(import.meta.url));

function parseScalar(value: string): string {
    return value.trim().replace(/^["']|["']$/g, "");
}

function parseFrontmatter(raw: string): { meta: Record<string, string | string[]>; content: string } {
    const match = raw.match(/^---\n([\s\S]*?)\n---\n?([\s\S]*)$/);
    if (!match) return { meta: {}, content: raw.trim() };

    const meta: Record<string, string | string[]> = {};
    const lines = match[1]?.split("\n") ?? [];
    let currentListKey: string | null = null;

    for (const line of lines) {
        const listMatch = line.match(/^\s*-\s+(.+)$/);
        if (listMatch && currentListKey) {
            const current = meta[currentListKey];
            const values = Array.isArray(current) ? current : [];
            values.push(parseScalar(listMatch[1] ?? ""));
            meta[currentListKey] = values;
            continue;
        }

        const pairMatch = line.match(/^([A-Za-z0-9_-]+):\s*(.*)$/);
        if (!pairMatch) continue;
        const key = pairMatch[1] ?? "";
        const value = pairMatch[2] ?? "";
        if (value.trim() === "") {
            currentListKey = key;
            meta[key] = [];
            continue;
        }
        currentListKey = null;
        meta[key] = parseScalar(value);
    }

    return { meta, content: (match[2] ?? "").trim() };
}

function stringValue(meta: Record<string, string | string[]>, key: string, fallback = ""): string {
    const value = meta[key];
    return typeof value === "string" ? value : fallback;
}

function numberValue(meta: Record<string, string | string[]>, key: string, fallback = 0): number {
    const value = Number.parseInt(stringValue(meta, key), 10);
    return Number.isFinite(value) ? value : fallback;
}

function booleanValue(meta: Record<string, string | string[]>, key: string): boolean | undefined {
    const value = meta[key];
    if (typeof value !== "string") return undefined;
    if (value === "true") return true;
    if (value === "false") return false;
    return undefined;
}

function triggersValue(meta: Record<string, string | string[]>): string[] {
    const value = meta.triggers;
    if (Array.isArray(value)) return value;
    if (typeof value === "string" && value.trim()) return [value.trim()];
    return [];
}

function priorityRank(priority: string): number {
    switch (priority.toLowerCase()) {
        case "critical":
            return 0;
        case "high":
            return 1;
        case "medium":
            return 2;
        case "low":
            return 3;
        default:
            return 4;
    }
}

export function loadSkillsFromDir(dir: string): SkillMarkdown[] {
    if (!existsSync(dir)) return [];
    return readdirSync(dir)
        .filter((fileName) => fileName.endsWith(".md"))
        .sort()
        .map((fileName) => {
            const raw = readFileSync(join(dir, fileName), "utf8");
            const { meta, content } = parseFrontmatter(raw);
            return {
                id: stringValue(meta, "id", fileName.replace(/\.md$/, "")),
                layer: numberValue(meta, "layer", 0),
                domain: stringValue(meta, "domain", "core"),
                triggers: triggersValue(meta),
                priority: stringValue(meta, "priority", "medium"),
                content,
                alwaysActive: booleanValue(meta, "always_active"),
                mode: stringValue(meta, "mode") || undefined,
            };
        });
}

export function findRelevantSkills(
    message: string,
    skills: SkillMarkdown[],
): SkillMarkdown[] {
    const normalized = message.toLowerCase();
    return skills
        .filter((skill) => skill.triggers.some((trigger) => normalized.includes(trigger.toLowerCase())))
        .sort((a, b) => priorityRank(a.priority) - priorityRank(b.priority));
}

function knowledgeRoot(): string {
    const candidates = [
        resolve(process.cwd(), "src", "knowledge"),
        __dirname,
        resolve(__dirname, "..", "..", "src", "knowledge"),
    ];
    return candidates.find((candidate) => existsSync(candidate)) ?? candidates[0] ?? __dirname;
}

export function loadAllGestorAISkills(): {
    core: SkillMarkdown[];
    gestorai: SkillMarkdown[];
} {
    const root = knowledgeRoot();
    return {
        core: loadSkillsFromDir(join(root, "core")),
        gestorai: loadSkillsFromDir(join(root, "gestorai")),
    };
}
