---
id: setup-api-key
layer: 0
domain: setup
triggers:
  - cambiar api key
  - api key inválida
  - no funciona la ia
  - cambiar proveedor
  - cambiar modelo
priority: high
always_active: false
---
# Cambiar API Key o Motor IA

Para cambiar la API key o el proveedor de IA:

gestoria config ai

El comando te guiará paso a paso.
La clave se guarda cifrada con AES-256-GCM.
Nunca se guarda en texto plano.

Para verificar que funciona:
gestoria doctor
