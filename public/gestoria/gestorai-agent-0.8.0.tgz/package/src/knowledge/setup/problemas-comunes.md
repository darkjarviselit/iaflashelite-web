---
id: setup-problemas
layer: 0
domain: setup
triggers:
  - no funciona
  - error
  - problema
  - no arranca
  - puerto ocupado
  - fallo
priority: high
always_active: false
---
# Problemas comunes en GestorIA

Problema: Puerto 7777 ocupado
Solución: Cierra otras instancias de GestorIA o
  cambia el puerto con: GESTORAI_PORT=7778 gestoria start

Problema: API key inválida
Solución: gestoria config ai
  Introduce tu nueva API key.

Problema: La UI no carga
Solución: npm run build

Problema: Base de datos corrupta
Solución: gestoria doctor para diagnóstico.
  Haz backup antes de cualquier acción.

Para diagnóstico completo:
gestoria doctor
