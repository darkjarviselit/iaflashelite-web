---
id: setup-instalacion
layer: 0
domain: setup
triggers:
  - cómo instalar
  - instalación
  - primeros pasos
  - cómo empezar
  - setup
priority: high
always_active: false
---
# Instalación de GestorIA

Requisitos: Node.js 20+, npm 10+

Instalación:
git clone https://github.com/darkjarviselit/gestorai-agent
cd gestorai-agent
npm install
gestoria setup

Para arrancar después:
gestoria start

Abre http://localhost:7777/chat
