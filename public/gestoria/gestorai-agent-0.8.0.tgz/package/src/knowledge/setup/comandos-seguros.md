---
id: setup-comandos
layer: 0
domain: setup
triggers:
  - qué comandos
  - comandos disponibles
  - cómo usar terminal
  - comandos seguros
priority: medium
always_active: false
---
# Comandos de GestorIA

Seguros (sin riesgo):
- gestoria start     → Arrancar la app
- gestoria doctor    → Diagnóstico
- gestoria config ai → Cambiar IA
- gestoria help      → Ver ayuda

Sensibles (modifican datos):
- gestoria setup     → Reconfigurar (pide confirmación si ya existe config)
- gestoria seed-demo → Carga datos de prueba

IMPORTANTE: Para comandos que modifiquen o borren datos,
GestorIA siempre pedirá confirmación antes de proceder.
Haz backup antes de operaciones importantes.
