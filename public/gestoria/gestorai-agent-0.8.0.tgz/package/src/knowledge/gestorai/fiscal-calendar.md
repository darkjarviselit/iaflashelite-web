---
id: fiscal-calendar
layer: 1
domain: gestoría
triggers:
  - plazo
  - vencimiento
  - modelo fiscal
  - impuesto
  - declaración
  - trimestre
priority: high
---
# Calendario fiscal básico España

Plazos trimestrales:
- Modelo 303 (IVA): hasta el 20 del mes siguiente al trimestre
  T1 (ene-mar): hasta 20 abril
  T2 (abr-jun): hasta 20 julio
  T3 (jul-sep): hasta 20 octubre
  T4 (oct-dic): hasta 30 enero
- Modelo 130 (IRPF autónomos): mismos plazos que 303
- Modelo 111 (retenciones): mismos plazos trimestrales
- Modelo 190 (resumen anual): hasta 31 enero
- Modelo 347 (operaciones terceros): hasta 28 febrero
- Renta anual: campaña abril-junio año siguiente

NOTA OBLIGATORIA: Estos plazos son orientativos.
El gestor siempre verifica en el calendario oficial
de la AEAT antes de confirmar a ningún cliente.
