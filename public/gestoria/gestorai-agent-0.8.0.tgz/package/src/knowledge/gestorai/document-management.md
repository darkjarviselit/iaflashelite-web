---
id: document-management
layer: 1
domain: gestoría
triggers:
  - documento pendiente
  - falta documentación
  - pedir documentos
  - checklist cliente
priority: high
---
# Gestión de documentación de clientes

Tipos de documentos habituales en gestorías:
- DNI/NIF del titular
- Facturas emitidas y recibidas
- Justificantes bancarios
- Modelos fiscales (303, 130, 111, 190, 347, 349)
- Contratos laborales y nóminas
- Documentos de constitución (escrituras, estatutos)

Flujo estándar de solicitud:
1. Identificar qué documentos faltan para el expediente
2. Generar mensaje personalizado al cliente
3. Actualizar checklist con estado "pendiente"
4. Seguimiento si no responde en 3 días hábiles
5. Marcar como "recibido" cuando llegue
6. Preparar resumen para el gestor
