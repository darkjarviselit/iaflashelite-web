---
id: fiscal-agenda
layer: 1
domain: gestoría
triggers:
  - qué vence
  - vencimientos
  - agenda
  - recordatorio
  - modelo 303
  - esta semana
  - próximos plazos
  - calendario
  - qué hay esta semana
  - recordatorios
  - plazo
  - vence
priority: high
---
# Agenda fiscal — GestorIA

Cuando el gestor pregunte sobre vencimientos o agenda:
1. Consultar GET /api/calendar/upcoming para próximos 7 días
2. Listar por urgencia: hoy → esta semana
3. Para cada evento con client_name: verificar documentos pendientes
4. Sugerir acción concreta: "Pedir Factura T2 a Martínez Ruiz antes del 20 jul"

Plazos orientativos (verificar siempre en AEAT):
- Modelo 303 T2: 20 julio
- Modelo 130 T2: 20 julio
- Modelo 111 T2: 20 julio
- Modelo 190: 31 enero
- Modelo 347: 28 febrero

NOTA OBLIGATORIA: Estos plazos son orientativos. El gestor siempre verifica
el calendario oficial de la AEAT antes de confirmar fechas a clientes.
