---
id: client-messages
layer: 1
domain: gestoría
triggers:
  - redactar mensaje
  - email cliente
  - whatsapp cliente
  - recordatorio
  - notificar
priority: medium
---
# Plantillas de mensajes para clientes

## Solicitud de documentos
Estimado/a [CLIENTE], le contactamos para informarle que
para completar su expediente de [CONCEPTO] necesitamos
los siguientes documentos: [LISTA].
Puede enviárnoslos por email o WhatsApp antes del [FECHA].
Quedamos a su disposición. Un saludo, [GESTORÍA].

## Recordatorio de plazo
Estimado/a [CLIENTE], le recordamos que el plazo para
[CONCEPTO] vence el [FECHA]. Si necesita ayuda para reunir
la documentación, contacte con nosotros con antelación.

## Confirmación de recepción
Estimado/a [CLIENTE], confirmamos la recepción de [DOCUMENTOS].
Los revisaremos y le informaremos si necesitamos algo más.
Gracias por su colaboración.

Tono siempre: profesional, amable, sin tecnicismos.
El gestor revisa siempre antes de enviar.
