# GestorIA — Agente IA para gestorías y contables

Agente IA con memoria persistente para gestorías y despachos
contables. Solicita documentos, organiza expedientes, genera
mensajes profesionales y recuerda el estado de cada cliente.

## Qué hace

- Solicita documentos pendientes a clientes
- Crea y gestiona checklists por cliente
- Genera borradores de mensajes para email o WhatsApp manual, siempre para revisión del gestor. WhatsApp real no está integrado todavía.
- Recuerda historial y estado de cada expediente
- Prepara resúmenes internos del estado de la gestoría

## Lo que NO hace

- No da asesoramiento fiscal vinculante
- No presenta impuestos automáticamente
- No accede a sistemas de la AEAT
- El gestor siempre revisa antes de enviar

## Instalación

```bash
npm install
npm run dev
```

## Configuración

Ejecuta el wizard al primer arranque.
Introduce el nombre de tu gestoría y configura tu LLM preferido.
